function(A) {
    return A.UA.mobile && A.UA.touchEnabled;
}
